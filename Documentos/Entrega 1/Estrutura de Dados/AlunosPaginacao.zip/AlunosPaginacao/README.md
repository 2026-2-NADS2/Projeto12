# Simulação de Listagem Paginada de Alunos (C# + SQLite)

Aplicação de console em **C# (.NET 8)** que simula a paginação de uma lista de
alunos, com os dados vindo de um **banco de dados relacional SQLite** real
(arquivo `alunos.db`), acessado via ADO.NET (`Microsoft.Data.Sqlite`).

## O que o projeto demonstra

- Criação automática do banco SQLite e da tabela `Alunos`, com dados
  fictícios pré-populados (57 registros) na primeira execução.
- Consulta paginada real no banco usando `LIMIT` / `OFFSET` (não carrega a
  tabela inteira em memória — cada "página" é uma consulta SQL separada).
- Menu de navegação no console: próxima página, página anterior, ir direto
  para uma página, primeira/última página, alterar o tamanho da página e
  busca por nome (também paginada).
- Separação em camadas: `Models` (entidade `Aluno`), `Data` (acesso ao banco
  e repositório) e `Services` (cálculos de paginação).

## Estrutura

```
AlunosPaginacao/
├── AlunosPaginacao.sln
├── README.md
└── src/
    └── AlunosPaginacao/
        ├── AlunosPaginacao.csproj
        ├── Program.cs                 # menu / ponto de entrada
        ├── Models/
        │   └── Aluno.cs
        ├── Data/
        │   ├── BancoDados.cs          # cria e popula o SQLite
        │   └── AlunoRepositorio.cs    # consultas paginadas (LIMIT/OFFSET)
        └── Services/
            └── PaginacaoService.cs    # cálculo de total de páginas etc.
```

## Como executar

Pré-requisito: **.NET SDK 8.0** instalado (https://dotnet.microsoft.com/download).

```bash
cd AlunosPaginacao
dotnet restore
dotnet run --project src/AlunosPaginacao
```

Na primeira execução, o programa cria o arquivo `alunos.db` (SQLite) na pasta
do executável e insere os alunos fictícios automaticamente. Nas execuções
seguintes, os mesmos dados são reaproveitados.

> Observação: o pacote NuGet `Microsoft.Data.Sqlite` é baixado no primeiro
> `dotnet restore`, portanto é necessário acesso à internet nesse passo (o
> código em si não faz nenhuma chamada de rede).

## Comandos do menu

| Tecla | Ação                                   |
|-------|-----------------------------------------|
| N     | Próxima página                          |
| P     | Página anterior                         |
| I     | Ir para a primeira página               |
| F     | Ir para a última página                 |
| Ir    | Digitar o número de uma página específica |
| T     | Trocar a quantidade de alunos por página |
| B     | Buscar alunos por nome (paginado)       |
| S     | Sair                                    |

## Possíveis extensões

- Trocar o SQLite por SQL Server/PostgreSQL (basta trocar a connection
  string e o driver ADO.NET/EF Core).
- Adicionar Entity Framework Core no lugar do ADO.NET puro.
- Transformar em uma API Web (ASP.NET Core) reaproveitando o
  `AlunoRepositorio`.
