using Microsoft.Data.Sqlite;

namespace AlunosPaginacao.Data;

/// <summary>
/// Responsável por criar o arquivo do banco relacional SQLite (caso não exista)
/// e popular a tabela "Alunos" com dados fictícios para a simulação.
/// </summary>
public static class BancoDados
{
    /// <summary>
    /// Caminho do arquivo .db. Fica na mesma pasta do executável.
    /// </summary>
    public static string CaminhoArquivo { get; } =
        Path.Combine(AppContext.BaseDirectory, "alunos.db");

    public static string ConnectionString => $"Data Source={CaminhoArquivo}";

    private static readonly string[] Nomes =
    {
        "Ana Souza", "Bruno Lima", "Carla Mendes", "Diego Alves", "Elaine Costa",
        "Fábio Rocha", "Gabriela Dias", "Hugo Martins", "Isabela Ramos", "João Pedro",
        "Karina Nunes", "Lucas Ferreira", "Mariana Silva", "Nicolas Barros", "Olivia Teixeira",
        "Pedro Henrique", "Quésia Farias", "Rafael Gomes", "Sabrina Castro", "Thiago Pereira",
        "Ursula Vieira", "Vitor Hugo", "Wesley Moraes", "Ximena Duarte", "Yasmin Cardoso",
        "Zeca Andrade", "Amanda Ribeiro", "Bernardo Cunha", "Camila Freitas", "Daniel Pinto"
    };

    private static readonly string[] Cursos =
    {
        "Ciência da Computação", "Engenharia de Software", "Sistemas de Informação",
        "Análise e Desenvolvimento de Sistemas", "Engenharia da Computação"
    };

    /// <summary>
    /// Cria a tabela (se necessário) e garante que existam alunos cadastrados,
    /// simulando uma base de dados já em produção.
    /// </summary>
    public static void Inicializar(int quantidadeDesejada = 57)
    {
        using var conexao = new SqliteConnection(ConnectionString);
        conexao.Open();

        using (var criaTabela = conexao.CreateCommand())
        {
            criaTabela.CommandText = """
                CREATE TABLE IF NOT EXISTS Alunos (
                    Id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    Nome            TEXT    NOT NULL,
                    Email           TEXT    NOT NULL,
                    Curso           TEXT    NOT NULL,
                    Matricula       TEXT    NOT NULL,
                    DataNascimento  TEXT    NOT NULL
                );
                """;
            criaTabela.ExecuteNonQuery();
        }

        long totalAtual;
        using (var contagem = conexao.CreateCommand())
        {
            contagem.CommandText = "SELECT COUNT(*) FROM Alunos;";
            totalAtual = (long)contagem.ExecuteScalar()!;
        }

        if (totalAtual >= quantidadeDesejada)
            return; // Banco já populado, nada a fazer.

        var random = new Random(42); // seed fixa -> dados reprodutíveis
        using var transacao = conexao.BeginTransaction();

        using var insere = conexao.CreateCommand();
        insere.Transaction = transacao;
        insere.CommandText = """
            INSERT INTO Alunos (Nome, Email, Curso, Matricula, DataNascimento)
            VALUES ($nome, $email, $curso, $matricula, $nascimento);
            """;

        var paramNome = insere.CreateParameter(); paramNome.ParameterName = "$nome";
        var paramEmail = insere.CreateParameter(); paramEmail.ParameterName = "$email";
        var paramCurso = insere.CreateParameter(); paramCurso.ParameterName = "$curso";
        var paramMatricula = insere.CreateParameter(); paramMatricula.ParameterName = "$matricula";
        var paramNascimento = insere.CreateParameter(); paramNascimento.ParameterName = "$nascimento";
        insere.Parameters.AddRange(new[] { paramNome, paramEmail, paramCurso, paramMatricula, paramNascimento });

        for (int i = (int)totalAtual; i < quantidadeDesejada; i++)
        {
            string nomeBase = Nomes[i % Nomes.Length];
            string nome = i < Nomes.Length ? nomeBase : $"{nomeBase} {i / Nomes.Length + 1}";
            string curso = Cursos[random.Next(Cursos.Length)];
            string emailLocal = nome.ToLowerInvariant()
                .Replace(" ", ".")
                .Normalize(System.Text.NormalizationForm.FormD);
            string email = $"{emailLocal}{i}@faculdade.edu.br";
            string matricula = $"2024{(i + 1000):D5}";
            var nascimento = new DateTime(
                random.Next(1998, 2007),
                random.Next(1, 13),
                random.Next(1, 28));

            paramNome.Value = nome;
            paramEmail.Value = email;
            paramCurso.Value = curso;
            paramMatricula.Value = matricula;
            paramNascimento.Value = nascimento.ToString("yyyy-MM-dd");

            insere.ExecuteNonQuery();
        }

        transacao.Commit();
    }
}
