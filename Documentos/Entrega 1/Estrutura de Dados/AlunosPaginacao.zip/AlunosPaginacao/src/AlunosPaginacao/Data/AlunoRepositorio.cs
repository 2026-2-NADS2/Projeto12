using Microsoft.Data.Sqlite;
using AlunosPaginacao.Models;

namespace AlunosPaginacao.Data;

/// <summary>
/// Encapsula o acesso ao banco relacional (SQLite) para a entidade Aluno,
/// incluindo a consulta paginada usada pela simulação de listagem.
/// </summary>
public class AlunoRepositorio
{
    /// <summary>
    /// Retorna o total de alunos cadastrados na tabela.
    /// </summary>
    public int ContarTotalAlunos()
    {
        using var conexao = new SqliteConnection(BancoDados.ConnectionString);
        conexao.Open();

        using var comando = conexao.CreateCommand();
        comando.CommandText = "SELECT COUNT(*) FROM Alunos;";
        return Convert.ToInt32(comando.ExecuteScalar());
    }

    /// <summary>
    /// Busca uma "página" de alunos diretamente no banco, usando LIMIT/OFFSET,
    /// que é a forma correta e eficiente de paginar dados em um SGBD relacional
    /// (evita carregar a tabela inteira em memória).
    /// </summary>
    /// <param name="numeroPagina">Página desejada, começando em 1.</param>
    /// <param name="tamanhoPagina">Quantidade de registros por página.</param>
    public List<Aluno> ObterPagina(int numeroPagina, int tamanhoPagina)
    {
        if (numeroPagina < 1) numeroPagina = 1;
        if (tamanhoPagina < 1) tamanhoPagina = 1;

        int offset = (numeroPagina - 1) * tamanhoPagina;

        using var conexao = new SqliteConnection(BancoDados.ConnectionString);
        conexao.Open();

        using var comando = conexao.CreateCommand();
        comando.CommandText = """
            SELECT Id, Nome, Email, Curso, Matricula, DataNascimento
            FROM Alunos
            ORDER BY Id
            LIMIT $tamanho OFFSET $offset;
            """;
        comando.Parameters.AddWithValue("$tamanho", tamanhoPagina);
        comando.Parameters.AddWithValue("$offset", offset);

        var lista = new List<Aluno>();
        using var leitor = comando.ExecuteReader();
        while (leitor.Read())
        {
            lista.Add(new Aluno
            {
                Id = leitor.GetInt32(0),
                Nome = leitor.GetString(1),
                Email = leitor.GetString(2),
                Curso = leitor.GetString(3),
                Matricula = leitor.GetString(4),
                DataNascimento = DateTime.Parse(leitor.GetString(5))
            });
        }

        return lista;
    }

    /// <summary>
    /// Busca alunos cujo nome contenha o termo informado (case-insensitive),
    /// já paginado. Usado pela opção de busca no menu.
    /// </summary>
    public (List<Aluno> Itens, int Total) BuscarPorNome(string termo, int numeroPagina, int tamanhoPagina)
    {
        if (numeroPagina < 1) numeroPagina = 1;
        if (tamanhoPagina < 1) tamanhoPagina = 1;
        int offset = (numeroPagina - 1) * tamanhoPagina;

        using var conexao = new SqliteConnection(BancoDados.ConnectionString);
        conexao.Open();

        int total;
        using (var comandoTotal = conexao.CreateCommand())
        {
            comandoTotal.CommandText = "SELECT COUNT(*) FROM Alunos WHERE Nome LIKE $termo;";
            comandoTotal.Parameters.AddWithValue("$termo", $"%{termo}%");
            total = Convert.ToInt32(comandoTotal.ExecuteScalar());
        }

        var lista = new List<Aluno>();
        using (var comando = conexao.CreateCommand())
        {
            comando.CommandText = """
                SELECT Id, Nome, Email, Curso, Matricula, DataNascimento
                FROM Alunos
                WHERE Nome LIKE $termo
                ORDER BY Id
                LIMIT $tamanho OFFSET $offset;
                """;
            comando.Parameters.AddWithValue("$termo", $"%{termo}%");
            comando.Parameters.AddWithValue("$tamanho", tamanhoPagina);
            comando.Parameters.AddWithValue("$offset", offset);

            using var leitor = comando.ExecuteReader();
            while (leitor.Read())
            {
                lista.Add(new Aluno
                {
                    Id = leitor.GetInt32(0),
                    Nome = leitor.GetString(1),
                    Email = leitor.GetString(2),
                    Curso = leitor.GetString(3),
                    Matricula = leitor.GetString(4),
                    DataNascimento = DateTime.Parse(leitor.GetString(5))
                });
            }
        }

        return (lista, total);
    }
}
