using AlunosPaginacao.Data;
using AlunosPaginacao.Models;
using AlunosPaginacao.Services;

Console.OutputEncoding = System.Text.Encoding.UTF8;

Console.WriteLine("==========================================================");
Console.WriteLine("   SIMULACAO DE LISTAGEM PAGINADA DE ALUNOS (SQLite)");
Console.WriteLine("==========================================================");

// 1) Garante que o banco relacional exista e esteja populado.
BancoDados.Inicializar(quantidadeDesejada: 57);
Console.WriteLine($"Banco de dados: {BancoDados.CaminhoArquivo}");

var repositorio = new AlunoRepositorio();

int tamanhoPagina = 10;
int paginaAtual = 1;

while (true)
{
    Console.Clear();
    int totalAlunos = repositorio.ContarTotalAlunos();
    int totalPaginas = PaginacaoService.CalcularTotalPaginas(totalAlunos, tamanhoPagina);
    paginaAtual = PaginacaoService.GarantirPaginaValida(paginaAtual, totalPaginas);

    List<Aluno> alunosDaPagina = repositorio.ObterPagina(paginaAtual, tamanhoPagina);

    ExibirCabecalho(totalAlunos, paginaAtual, totalPaginas, tamanhoPagina);
    ExibirAlunos(alunosDaPagina);
    ExibirMenu();

    string? opcao = Console.ReadLine()?.Trim().ToLowerInvariant();

    switch (opcao)
    {
        case "n":
        case "proxima":
            if (paginaAtual < totalPaginas) paginaAtual++;
            break;

        case "p":
        case "anterior":
            if (paginaAtual > 1) paginaAtual--;
            break;

        case "i":
            paginaAtual = 1;
            break;

        case "f":
            paginaAtual = totalPaginas;
            break;

        case "ir":
            Console.Write("Digite o numero da pagina desejada: ");
            if (int.TryParse(Console.ReadLine(), out int paginaEscolhida))
                paginaAtual = PaginacaoService.GarantirPaginaValida(paginaEscolhida, totalPaginas);
            break;

        case "t":
            Console.Write("Novo tamanho de pagina (registros por pagina): ");
            if (int.TryParse(Console.ReadLine(), out int novoTamanho) && novoTamanho > 0)
            {
                tamanhoPagina = novoTamanho;
                paginaAtual = 1;
            }
            break;

        case "b":
            RealizarBusca(repositorio, tamanhoPagina);
            break;

        case "s":
        case "sair":
            Console.WriteLine("\nEncerrando aplicacao. Ate mais!");
            return;

        default:
            Console.WriteLine("\nOpcao invalida. Pressione ENTER para continuar...");
            Console.ReadLine();
            break;
    }
}

// ---------------------------------------------------------------------
// Funcoes auxiliares de apresentacao (mantidas no Program.cs por simplicidade)
// ---------------------------------------------------------------------

static void ExibirCabecalho(int totalAlunos, int paginaAtual, int totalPaginas, int tamanhoPagina)
{
    Console.WriteLine("==========================================================");
    Console.WriteLine("   SIMULACAO DE LISTAGEM PAGINADA DE ALUNOS (SQLite)");
    Console.WriteLine("==========================================================");
    Console.WriteLine($"Total de alunos: {totalAlunos}   |   Registros por pagina: {tamanhoPagina}");
    Console.WriteLine($"Pagina {paginaAtual} de {(totalPaginas == 0 ? 1 : totalPaginas)}");
    Console.WriteLine("----------------------------------------------------------");
}

static void ExibirAlunos(List<Aluno> alunos)
{
    if (alunos.Count == 0)
    {
        Console.WriteLine("Nenhum aluno encontrado.");
    }
    else
    {
        Console.WriteLine($"{"Id",-4} {"Nome",-28} {"Matricula",-12} {"Curso",-22} {"Idade",5}  Email");
        Console.WriteLine(new string('-', 100));
        foreach (var aluno in alunos)
            Console.WriteLine(aluno.ToString());
    }
    Console.WriteLine("----------------------------------------------------------");
}

static void ExibirMenu()
{
    Console.WriteLine("[N] Proxima pagina   [P] Pagina anterior   [I] Primeira   [F] Ultima");
    Console.WriteLine("[Ir] Ir para pagina   [T] Trocar tamanho da pagina   [B] Buscar por nome   [S] Sair");
    Console.Write("Escolha uma opcao: ");
}

static void RealizarBusca(AlunoRepositorio repositorio, int tamanhoPagina)
{
    Console.Write("\nDigite parte do nome do aluno: ");
    string termo = Console.ReadLine()?.Trim() ?? string.Empty;

    if (string.IsNullOrWhiteSpace(termo))
    {
        Console.WriteLine("Termo vazio. Pressione ENTER para voltar...");
        Console.ReadLine();
        return;
    }

    int paginaBusca = 1;
    while (true)
    {
        var (itens, total) = repositorio.BuscarPorNome(termo, paginaBusca, tamanhoPagina);
        int totalPaginasBusca = PaginacaoService.CalcularTotalPaginas(total, tamanhoPagina);
        paginaBusca = PaginacaoService.GarantirPaginaValida(paginaBusca, totalPaginasBusca);

        Console.Clear();
        Console.WriteLine($"Resultados para \"{termo}\": {total} encontrado(s)");
        Console.WriteLine($"Pagina {paginaBusca} de {(totalPaginasBusca == 0 ? 1 : totalPaginasBusca)}");
        Console.WriteLine("----------------------------------------------------------");
        ExibirAlunos(itens);
        Console.WriteLine("[N] Proxima   [P] Anterior   [S] Voltar ao menu principal");
        Console.Write("Escolha uma opcao: ");

        string? opcao = Console.ReadLine()?.Trim().ToLowerInvariant();
        if (opcao == "n" && paginaBusca < totalPaginasBusca) paginaBusca++;
        else if (opcao == "p" && paginaBusca > 1) paginaBusca--;
        else if (opcao == "s") return;
    }
}
