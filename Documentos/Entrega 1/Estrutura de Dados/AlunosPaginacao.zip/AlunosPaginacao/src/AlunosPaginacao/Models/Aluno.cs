namespace AlunosPaginacao.Models;

/// <summary>
/// Representa um aluno tal como armazenado na tabela "Alunos" do banco SQLite.
/// </summary>
public class Aluno
{
    public int Id { get; set; }
    public string Nome { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Curso { get; set; } = string.Empty;
    public string Matricula { get; set; } = string.Empty;
    public DateTime DataNascimento { get; set; }

    public override string ToString()
    {
        int idade = CalcularIdade(DataNascimento);
        return $"{Id,-4} {Nome,-28} {Matricula,-12} {Curso,-22} {idade,3} anos  {Email}";
    }

    private static int CalcularIdade(DateTime nascimento)
    {
        var hoje = DateTime.Today;
        int idade = hoje.Year - nascimento.Year;
        if (nascimento.Date > hoje.AddYears(-idade)) idade--;
        return idade;
    }
}
