namespace AlunosPaginacao.Services;

/// <summary>
/// Pequenos cálculos reaproveitados pela paginação (total de páginas, limites, etc).
/// </summary>
public static class PaginacaoService
{
    public static int CalcularTotalPaginas(int totalRegistros, int tamanhoPagina)
    {
        if (tamanhoPagina < 1) tamanhoPagina = 1;
        return (int)Math.Ceiling(totalRegistros / (double)tamanhoPagina);
    }

    public static int GarantirPaginaValida(int paginaDesejada, int totalPaginas)
    {
        if (totalPaginas <= 0) return 1;
        if (paginaDesejada < 1) return 1;
        if (paginaDesejada > totalPaginas) return totalPaginas;
        return paginaDesejada;
    }
}
